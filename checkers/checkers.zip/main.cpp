#include "checkers.h"

int main() {

    board newBoard;
    //newBoard.specialBoard();
    newBoard.playGame();
    return 0;

}
